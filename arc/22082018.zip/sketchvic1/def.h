#include <arduino.h>

#ifndef VIC_DEV
  #define VIC_DEV
  
  #define RC_NOTHING 0
  #define RC_UNKNOWN 1
  #define RC_DEVICEOFF 2
  #define RC_DEVICEON 3
  
  #define MAX_LONG 0xFFFFFFFF
  #define PHONENUM "+79160265679"
  //#define PHONENUM2"+79850455595"
  #define PHONENUM2"+79262107898"	

	
	#define SSR_1  7
	#define SSR_2  5
	#define SSR_W  6 // 9 цифровой пин для включения подогрева воды
 
  #define THERMROOMIN  3
 
  
  #define MAXROOMTEMP  25 // максимальная температура в комнате
  //#define HIGHBOXTEMP  40 //максимальная темппература в корпусе, после которой включается вентилятор охлаждения
  #define DELTATEMP 2 //гестерезис температуры

  #ifndef _TRACE 
   #define _TRACE
  #endif  
const char help_msg[]			PROGMEM	= { "GSM INIT\nSTART ALL\nSTART NO HEAT\nSTOP ALL\nSTOP NO HEAT\nSTOP ONLY HEAT\nSTATUS\nSET TEMP=25 \nSET DELTA=2" };
const char rt_msg[]				PROGMEM = { "ROOM TEMP = " };
const char water_msg[]			PROGMEM = { "WATER " };
const char htr_msg[]			PROGMEM = { "HEAT  " };
const char on_msg[]				PROGMEM = { "ON" };
const char off_msg[]			PROGMEM = { "OFF" };

const char sn_msg[]				PROGMEM = { "\n" };
const char fr_msg[]				PROGMEM = { "FR= " };
const char gsci_msg[]			PROGMEM = { "Get sms command at index: " };

const char cmd_start_all[]		PROGMEM = { "STARTALL\0" };
const char cmd_start_no_heat[]	PROGMEM = { "STARTNOHEAT" };
const char cmd_stop_all[]		PROGMEM = { "STOPALL" };
const char cmd_stop_no_heat[]	PROGMEM = { "STOPNOHEAT" };
const char cmd_stop_only_heat[]	PROGMEM = { "STOPONLYHEAT" };
const char cmd_status[]			PROGMEM = { "STATUS" };
const char cmd_set_temp[]		PROGMEM = { "SETTEMP" };
const char cmd_set_delta[]		PROGMEM = { "SETDELTA" };
const char cmd_help[]			PROGMEM = { "HELP" };


const char ts_msg[]				PROGMEM = { "TEMP SET  "};
const char ds_msg[]				PROGMEM = { "DELTA SET "};


class SSR
{
public:
  SSR(){};
  ~SSR(){};
  void Init(){};
  void On()
  {
    
  };
  void Off() {
    digitalWrite(SSR_1, HIGH);
    delay(500);
	digitalWrite(SSR_2, LOW);
	delay(500);
    digitalWrite(SSR_W, HIGH);
    delay(500);
  };
  void Blink() { // когда все хорошо 5 морганий
	  int led = 13;
	  pinMode(led, OUTPUT);
	  for (int i = 0; i < 5; i++)
	  {
		  digitalWrite(led, HIGH); // turn the LED on (HIGH is the voltage level)
		  delay(1000);
		  digitalWrite(led, LOW); // turn the LED off by making the voltage LOW
		  delay(1000);
	  }
  }
  void ErrorBlink() {//когда плохо, то три долгих
	  int led = 13;
	  pinMode(led, OUTPUT);
	  for (int i = 0; i < 3; i++)
	  {
		  digitalWrite(led, HIGH); // turn the LED on (HIGH is the voltage level)
		  delay(3000);
		  digitalWrite(led, LOW); // turn the LED off by making the voltage LOW
		  delay(3000);
	  }
  }
  int freeRam() {
	extern int __heap_start, *__brkval;
	int v;
	return (int)&v - (__brkval == 0 ? (int)&__heap_start : (int)__brkval);
  }

};
#endif
